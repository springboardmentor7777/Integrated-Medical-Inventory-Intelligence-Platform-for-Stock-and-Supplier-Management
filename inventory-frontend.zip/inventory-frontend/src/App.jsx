import { useState } from "react";
import Dashboard from "./components/Dashboard";
import Inventory from "./components/Inventory";

export default function App() {
  const [view, setView] = useState("dashboard");
  return (
    <main>
      <nav aria-label="Main">
        <button aria-pressed={view === "dashboard"} onClick={() => setView("dashboard")}>Dashboard</button>
        <button aria-pressed={view === "inventory"} onClick={() => setView("inventory")}>Inventory</button>
      </nav>
      {view === "dashboard" ? <Dashboard /> : <Inventory />}
    </main>
  );
}
