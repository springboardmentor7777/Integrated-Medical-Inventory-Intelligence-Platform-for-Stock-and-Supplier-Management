export function categoryBreakdown(items) {
  const map = {};
  for (const i of items) map[i.category] = (map[i.category] || 0) + 1;
  return Object.entries(map).map(([name, value]) => ({ name, value }));
}

export function summarize(items, lowStockAt = 10) {
  return {
    totalItems: items.length,
    totalUnits: items.reduce((s, i) => s + i.quantity, 0),
    lowStock: items.filter((i) => i.quantity <= lowStockAt).length,
    categories: new Set(items.map((i) => i.category)).size,
  };
}
