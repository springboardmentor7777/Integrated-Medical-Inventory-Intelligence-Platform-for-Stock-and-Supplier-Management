const BASE = import.meta.env.VITE_API_URL || "http://localhost:8000/api";

async function get(path) {
  const res = await fetch(`${BASE}${path}`);
  if (!res.ok) throw new Error(`Request to ${path} failed (${res.status})`);
  return res.json();
}

// Adjust paths to match your backend routes.
export const fetchInventory = () => get("/inventory");
export const fetchStockMovement = () => get("/analytics/stock-movement");
export const API_BASE = BASE;
