import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { vi } from "vitest";
import Inventory from "../components/Inventory";
import * as api from "../api";

vi.mock("../api");

const items = [
  { id: 1, name: "Bolt", category: "Hardware", quantity: 5 },
  { id: 2, name: "Paint", category: "Supplies", quantity: 20 },
];

test("renders rows and filters by search", async () => {
  api.fetchInventory.mockResolvedValue(items);
  render(<Inventory />);

  expect(await screen.findByText("Bolt")).toBeInTheDocument();
  expect(screen.getByText("Paint")).toBeInTheDocument();

  await userEvent.type(screen.getByLabelText(/search items/i), "paint");
  expect(screen.queryByText("Bolt")).not.toBeInTheDocument();
  expect(screen.getByText("Paint")).toBeInTheDocument();
});

test("shows no-match message", async () => {
  api.fetchInventory.mockResolvedValue(items);
  render(<Inventory />);
  await screen.findByText("Bolt");
  await userEvent.type(screen.getByLabelText(/search items/i), "zzz");
  expect(screen.getByText(/no items match/i)).toBeInTheDocument();
});
