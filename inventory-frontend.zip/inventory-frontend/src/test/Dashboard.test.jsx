import { render, screen } from "@testing-library/react";
import { vi } from "vitest";
import Dashboard from "../components/Dashboard";
import * as api from "../api";

vi.mock("../api");

const items = [
  { id: 1, name: "Bolt", category: "Hardware", quantity: 5 },
  { id: 2, name: "Nut", category: "Hardware", quantity: 50 },
  { id: 3, name: "Paint", category: "Supplies", quantity: 20 },
];
const movement = [
  { date: "2026-09-01", in: 10, out: 4, level: 70 },
  { date: "2026-09-02", in: 5, out: 8, level: 67 },
];

test("shows summary cards and charts", async () => {
  api.fetchInventory.mockResolvedValue(items);
  api.fetchStockMovement.mockResolvedValue(movement);
  render(<Dashboard />);

  expect(await screen.findByText("Total items")).toBeInTheDocument();
  expect(screen.getByText("75")).toBeInTheDocument();
  expect(screen.getByLabelText(/bar chart/i)).toBeInTheDocument();
  expect(screen.getByLabelText(/pie chart/i)).toBeInTheDocument();
  expect(screen.getByLabelText(/line chart/i)).toBeInTheDocument();
});

test("shows an error when the API fails", async () => {
  api.fetchInventory.mockRejectedValue(new Error("boom"));
  api.fetchStockMovement.mockResolvedValue([]);
  render(<Dashboard />);
  expect(await screen.findByRole("alert")).toHaveTextContent(/boom/);
});

test("shows empty state with no items", async () => {
  api.fetchInventory.mockResolvedValue([]);
  api.fetchStockMovement.mockResolvedValue([]);
  render(<Dashboard />);
  expect(await screen.findByText(/no inventory yet/i)).toBeInTheDocument();
});
