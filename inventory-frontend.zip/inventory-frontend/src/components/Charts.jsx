import {
  BarChart, Bar, PieChart, Pie, Cell, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from "recharts";

const COLORS = ["#2f6f62", "#c9822b", "#4a5fa8", "#a8483f", "#7a6a9c", "#5d8a3a"];

export function CategoryBarChart({ data }) {
  return (
    <div role="img" aria-label="Bar chart of items per category" className="chart">
      <ResponsiveContainer width="100%" height={260}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="name" />
          <YAxis allowDecimals={false} />
          <Tooltip />
          <Bar dataKey="value" name="Items" fill={COLORS[0]} radius={[3, 3, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function CategoryPieChart({ data }) {
  return (
    <div role="img" aria-label="Pie chart of category share" className="chart">
      <ResponsiveContainer width="100%" height={260}>
        <PieChart>
          <Pie data={data} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90}>
            {data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
          </Pie>
          <Tooltip />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

// data: [{ date: "2026-09-01", in: 40, out: 25, level: 320 }, ...]
export function StockTrendChart({ data }) {
  return (
    <div role="img" aria-label="Line chart of stock movement over time" className="chart">
      <ResponsiveContainer width="100%" height={280}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="date" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="level" name="Stock level" stroke={COLORS[0]} strokeWidth={2} dot={false} />
          <Line type="monotone" dataKey="in" name="Received" stroke={COLORS[2]} dot={false} />
          <Line type="monotone" dataKey="out" name="Shipped" stroke={COLORS[3]} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
