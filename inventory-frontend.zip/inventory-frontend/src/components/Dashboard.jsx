import { fetchInventory, fetchStockMovement } from "../api";
import { useAsync } from "../useAsync";
import { categoryBreakdown, summarize } from "../utils";
import { CategoryBarChart, CategoryPieChart, StockTrendChart } from "./Charts";

const loadAll = () => Promise.all([fetchInventory(), fetchStockMovement()]);

export default function Dashboard() {
  const { data, error, loading } = useAsync(loadAll);

  if (loading) return <p role="status">Loading dashboard…</p>;
  if (error) return <p role="alert">Couldn't load dashboard data: {error.message}</p>;

  const [items, movement] = data;
  const s = summarize(items);
  const cats = categoryBreakdown(items);

  return (
    <section aria-labelledby="dash-title">
      <h2 id="dash-title">Dashboard</h2>
      <div className="cards">
        <Card label="Total items" value={s.totalItems} />
        <Card label="Units in stock" value={s.totalUnits} />
        <Card label="Low stock" value={s.lowStock} />
        <Card label="Categories" value={s.categories} />
      </div>
      {items.length === 0 ? (
        <p>No inventory yet. Add your first item to see charts here.</p>
      ) : (
        <>
          <div className="grid2">
            <div><h3>Items by category</h3><CategoryBarChart data={cats} /></div>
            <div><h3>Category share</h3><CategoryPieChart data={cats} /></div>
          </div>
          <h3>Stock movement</h3>
          <StockTrendChart data={movement} />
        </>
      )}
    </section>
  );
}

function Card({ label, value }) {
  return (
    <div className="card">
      <div className="card-value">{value}</div>
      <div className="card-label">{label}</div>
    </div>
  );
}
