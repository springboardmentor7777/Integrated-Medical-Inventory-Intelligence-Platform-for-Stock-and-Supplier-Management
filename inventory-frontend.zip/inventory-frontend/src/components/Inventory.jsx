import { useState } from "react";
import { fetchInventory } from "../api";
import { useAsync } from "../useAsync";

export default function Inventory() {
  const { data, error, loading } = useAsync(fetchInventory);
  const [query, setQuery] = useState("");

  if (loading) return <p role="status">Loading inventory…</p>;
  if (error) return <p role="alert">Couldn't load inventory: {error.message}</p>;

  const rows = data.filter((i) =>
    `${i.name} ${i.category}`.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <section aria-labelledby="inv-title">
      <h2 id="inv-title">Inventory</h2>
      <label>
        Search items
        <input value={query} onChange={(e) => setQuery(e.target.value)} />
      </label>
      {rows.length === 0 ? (
        <p>No items match your search.</p>
      ) : (
        <table>
          <thead>
            <tr><th>Name</th><th>Category</th><th>Quantity</th></tr>
          </thead>
          <tbody>
            {rows.map((i) => (
              <tr key={i.id}>
                <td>{i.name}</td><td>{i.category}</td><td>{i.quantity}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </section>
  );
}
